print("***FORM***")
name=(input("Enter first name:"))
lname=(input("Enter last name:"))
fatname=(input("Enter Father's name:"))
age=(input("Enter age:"))
test=int(input("Enter test date (dates available 2,4,6 February 2023):"))
per=float(input("Enter percentage of Second year:"))    
a='admission test slip'
list1=["Computer Science and Information Technology","Software Engineering","Computer Systems"]
list2=["Chemical Engineering","Electrical Engineering","Electronic Engineering","Mechanical Engineering"]
list3=["Architecture and Planning","Automotive Engineering","Civil Engineering","Construction Engineering","Industrial and Manufacture","Manufacture Engineering","Telecommunication","Textile Engineering"]
list4=["Bio Engineering","Food Engineering", "Medical Engineering","Polymer and Petrochemical Engineering","Urban Engineering"]
while 1:
    date=(input("Enter date of birth (dd/mm/yyyy):"))
    d=int (date[0:2])
    m=int(date[2:4])
    y=int (date[4:8])
    if (d<=31) and (m<=12):
        break
    else:
        print("invalid date")
print("****** ADMISSION TEST SLIP ******")
print("First name:"+name.title()+"\nLast name:"+lname.title()+"\nFather's name:"+fatname.title()+"\nDate of birth:"+date+"\nAge:"+age+"\n")
def program():
    print("Programs you can apply for:"+"\n")
    if per>=80 and per<=85:
        for i in list1:
            print("*",i)
    elif per>=86 and per<=100:
        for k in list2:
            print("*",k)
    elif per>=70 and per<76:
        for j in list4:
            print("*",j)
    elif per>=76 and per<=79:
        for l in list3:
            print("*",l)
    return
program()
if (test==2) or (test==4) or (test==6):
    print("Test date:",test)
else:
    print("Invalid date")
print("*******************************")